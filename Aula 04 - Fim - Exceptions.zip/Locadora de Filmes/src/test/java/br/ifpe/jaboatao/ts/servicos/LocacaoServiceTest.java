package br.ifpe.jaboatao.ts.servicos;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.Date;

import org.junit.jupiter.api.Test;

import br.ifpe.jaboatao.ts.entidades.Filme;
import br.ifpe.jaboatao.ts.entidades.Locacao;
import br.ifpe.jaboatao.ts.entidades.Usuario;
import br.ifpe.jaboatao.ts.exceptions.FilmeException;
import br.ifpe.jaboatao.ts.utils.DataUtils;

public class LocacaoServiceTest {
	@Test
	public void teste01() throws FilmeException {
		//cenário
		LocacaoService service = new LocacaoService();
		Usuario usuario = new Usuario("Carlos");
		Filme filme = new Filme("Titulo 1", 1, 10.00);
		
		//ação
		Locacao locacao = service.alugarFilme(usuario, filme);
		
		//verificação
		assertEquals(10.00, locacao.getValorLocacao() );
		assertTrue(DataUtils.boDatasIguais(locacao.getDataLocacao(), new Date()));
		assertTrue(DataUtils.boDatasIguais(locacao.getDataRetorno(), DataUtils.incrementarQntDias(1)));
		
		//Exercício:
		//Crie os seguintes testes:
		//Nome do usuário
		assertEquals("Carlos", locacao.getUsuario().getNome());
		//Título do filme
		assertEquals("Titulo 1", locacao.getFilme().getTitulo());
		//Estoque do filme
		assertEquals(1, locacao.getFilme().getEstoque());
	}
	@Test
	public void teste02() {
		//Cenário
		LocacaoService service = new LocacaoService();
		Usuario usuario = new Usuario("Usuario 01");
		Filme filme = new Filme("Titulo 01", 0, 10.00);
		
		//Ação
		try {
			Locacao locacao = service.alugarFilme(usuario, filme);
			fail("Deveria ter ocorrido uma exception.");
		} catch (FilmeException e) {
			//Verificação
			assertEquals("Estoque vazio.", e.getMessage());
		}
		
	}
	@Test
	public void teste03() {
		//Cenário
		LocacaoService service = new LocacaoService();
		Usuario usuario = new Usuario("Usuario 01");
		Filme filme = new Filme("Titulo 01", 0, 10.00);
		
		//ação
		FilmeException minhaException = assertThrows(FilmeException.class, () -> {
			service.alugarFilme(usuario, filme);
		}, "Deveria ter ocorrido uma exception.");
		
		//Verificação
		assertEquals("Estoque vazio.", minhaException.getMessage());
	}
	@Test
	public void teste04() {
		//Cenário
		LocacaoService service = new LocacaoService();
		Usuario usuario = new Usuario("");
		Filme filme = new Filme("Titulo 01", 10, 10.00);
		
		//Ação
		try {
			Locacao locacao = service.alugarFilme(usuario, filme);
			fail("Deveria ter ocorrido uma exception.");
		} catch (FilmeException e) {
			//Verificação
			assertEquals("Nome vazio.", e.getMessage());
		}
		
	}
	@Test
	public void teste05() {
		//Cenário
		LocacaoService service = new LocacaoService();
		Usuario usuario = new Usuario("");
		Filme filme = new Filme("Titulo 01", 10, 10.00);
		
		//ação
		FilmeException minhaException = assertThrows(FilmeException.class, () -> {
			service.alugarFilme(usuario, filme);
		}, "Deveria ter ocorrido uma exception.");
		
		//Verificação
		assertEquals("Nome vazio.", minhaException.getMessage());
	}
}
